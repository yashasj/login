package myfiles;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
      
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 

	{

	    /* TODO : IMPLEMENT YOUR CODE HERE */

	    String uname = "accenture";

	    String pwd = "password123";

        String username = request.getParameter("uname");

        String password = request.getParameter("pwd");

        

        if(username.equals(uname) && password.equals(pwd)){

            RequestDispatcher rd = request.getRequestDispatcher("true.jsp");

            rd.forward(request,response);

        }

        else{

            RequestDispatcher rd = request.getRequestDispatcher("false.jsp");

            rd.forward(request,response);

        }

	}
}